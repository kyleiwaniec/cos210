// Insert solution to programming exercise 3, section 11, chapter 2 here
