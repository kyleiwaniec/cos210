package KW.CH02;

/**
 * This is an implementation of the PhoneDirectoryInterface
 * that uses an ArrayList to store the data.
 * @author Koffman and Wolfgang
 */
import java.util.ArrayList;

public class PhoneDirectory {

    // Data fields
    /** The ArrayList to contain the directory data */
    private ArrayList<DirectoryEntry> theDirectory =
            new ArrayList<DirectoryEntry>();


// Insert solution to programming exercise 1, section 2, chapter 2 here


// Insert solution to programming exercise 2, section 2, chapter 2 here
}
