// Insert solution to programming exercise 2, section 11, chapter 2 here
