// Insert solution to programming exercise 1, section 11, chapter 2 here
