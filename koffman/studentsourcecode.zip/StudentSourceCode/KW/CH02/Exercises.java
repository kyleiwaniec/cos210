package KW.CH02;

import java.util.ArrayList;

/**
 * Class to contain static method exercise solutions
 */
public class Exercises {

// Insert solution to programming exercise 1, section 1, chapter 2 here

// Insert solution to programming exercise 2, section 1, chapter 2 here
}
