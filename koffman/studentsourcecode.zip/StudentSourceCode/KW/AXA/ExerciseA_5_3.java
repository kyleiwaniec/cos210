/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseA_5_3 {

    public static void main(String[] args) {
        String sentence = "Let's all learn how to program in Java";
        String[] tokens = sentence.split("\\s+");
// Insert solution to programming exercise 3, section 5, chapter A here
    }

}
