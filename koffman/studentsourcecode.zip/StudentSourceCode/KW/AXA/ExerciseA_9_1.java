/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

import javax.swing.JOptionPane;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseA_9_1 {

// Insert solution to programming exercise 1, section 9, chapter A here

}
