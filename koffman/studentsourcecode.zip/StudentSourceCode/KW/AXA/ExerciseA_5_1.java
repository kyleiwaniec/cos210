/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseA_5_1 {

    public static void main(String[] args) {
        String s = "Doe, John 5/15/65";
// Insert solution to programming exercise 1, section 5, chapter A here
        System.out.println(token1);
        System.out.println(token2);
        System.out.println(token3);
        System.out.println(token4);
        System.out.println(token5);
    }

}
