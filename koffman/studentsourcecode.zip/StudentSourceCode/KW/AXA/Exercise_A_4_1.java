/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class Exercise_A_4_1 {

// Insert solution to programming exercise 1, section 4, chapter A here
}
