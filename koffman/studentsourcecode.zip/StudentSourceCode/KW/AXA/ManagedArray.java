/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ManagedArray {
    
    private int[] x;
    private static final int MIN_VAL = 0;
    private static final int MAX_VAL = 1000;
    
    public ManagedArray(int n) {
        x = new int[n];
    }
    
// Insert solution to programming exercise 2, section 12, chapter A here
    
    public static void main(String[] args) {
        ManagedArray a = new ManagedArray(10);
// Insert solution to programming exercise 2, section 12, chapter A here
    }

}
