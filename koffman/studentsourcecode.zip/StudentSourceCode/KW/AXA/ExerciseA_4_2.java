/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseA_4_2 {

// Insert solution to programming exercise 2, section 4, chapter A here

}
