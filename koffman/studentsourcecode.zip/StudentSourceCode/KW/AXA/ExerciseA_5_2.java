/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseA_5_2 {

    public static void main(String[] args) {
        String s = "Nancy* has thrity-three*** fine!! teath.";
// Insert solution to programming exercise 2, section 5, chapter A here
        System.out.println(stb.toString());

    }
}
