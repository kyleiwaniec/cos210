/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseA_3_1 {

    public static void main(String[] args) {
        int sum = 0;
        int prod = 1;
        int maxValue = 10;
// Insert solution to programming exercise 1, section 3, chapter A here
    }
}
