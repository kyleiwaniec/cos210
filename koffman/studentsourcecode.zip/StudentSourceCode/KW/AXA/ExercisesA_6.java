/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXA;

/**
 *
 * @author Paul Wolfgang
 */
public class ExercisesA_6 {

    public static void main(String[] args) {

        Integer i1 = new Integer(10);
        Integer i2 = new Integer(20);
        Integer i3 = new Integer(30);
        Integer i4 = null;

// Insert solution to programming exercise 1, section 6, chapter A here

// Insert solution to programming exercise 2, section 6, chapter A here

        System.out.println("i1 " + i1);
        System.out.println("i2 " + i2);
        System.out.println("i3 " + i3);
        System.out.println("i4 " + i4);
    }

}
