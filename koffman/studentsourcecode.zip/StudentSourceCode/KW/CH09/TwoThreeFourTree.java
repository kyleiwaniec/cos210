// Insert solution to programming project 3, chapter -1 here
// Insert solution to programming exercise 2, section 5, chapter 9 here
