package KW.CH04;

import java.util.Deque;
import java.util.ArrayDeque;
import java.util.Scanner;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Exercise_4_4 {

    public static void main(String[] args) {

// Insert solution to programming exercise 1, section 4, chapter 4 here

// Insert solution to programming exercise 2, section 4, chapter 4 here
    }
}
