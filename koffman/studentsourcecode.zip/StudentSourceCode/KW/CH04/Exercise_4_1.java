package KW.CH04;

import java.util.Stack;
import java.util.Queue;
import java.util.ArrayDeque;

public class Exercise_4_1 {

    public static void main(String[] args) {

// Insert solution to programming exercise 1, section 1, chapter 4 here

// Insert solution to programming exercise 2, section 1, chapter 4 here

// Insert solution to programming exercise 3, section 1, chapter 4 here
    }
}
