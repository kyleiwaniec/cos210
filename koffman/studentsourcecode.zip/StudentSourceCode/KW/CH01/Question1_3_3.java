// Inset solution to self-check exercise 3, section 3, chapter 1 here
