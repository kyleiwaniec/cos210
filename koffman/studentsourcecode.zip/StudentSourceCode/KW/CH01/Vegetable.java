// Insert solution to programming exercise 1, section 4, chapter 1 here
