// Insert solution to programming exercise 2, section 8, chapter 1 here
