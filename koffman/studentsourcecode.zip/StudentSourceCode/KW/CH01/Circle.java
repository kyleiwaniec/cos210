// Insert solution to programming exercise 1, section 8, chapter 1 here
