package KW.CH01;

/**
 * Class Airplane example for Exercise 1.5.3
 */
public class Airplane {

    private Engine eng;
    private Rudder rud;
    private Wing[] wings = new Wing[2];

// Insert solution to programming exercise 3, section 5, chapter 1 here
}

// Dummy classes to allow exercise to compile
class Engine {
}

class Rudder {
}

class Wing {
}
