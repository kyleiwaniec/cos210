// Insert solution to programming exercise 2, section 6, chapter 8 here
