package KW.CH08;

/**
 * Class to extend QuickSort implementing the second version of the
 * partition Algorithm
 * @author Paul Wolfgang
 */
public class QuickSort3 extends QuickSort2 {

// Insert solution to programming exercise 1, section 11, chapter 8 here
}
