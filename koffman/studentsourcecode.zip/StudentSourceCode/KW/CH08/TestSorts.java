// Insert solution to programming exercise 3, section 10, chapter 8 here
