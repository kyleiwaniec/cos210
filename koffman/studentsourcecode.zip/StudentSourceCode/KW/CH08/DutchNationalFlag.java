// Insert solution to programming project 8, chapter -1 here
