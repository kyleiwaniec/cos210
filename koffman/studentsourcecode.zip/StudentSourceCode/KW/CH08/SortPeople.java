package KW.CH08;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortPeople {

// Insert solution to programming exercise 1, section 1, chapter 8 here

// Insert solution to programming exercise 2, section 1, chapter 8 here

// Insert solution to programming exercise 3, section 1, chapter 8 here
}
