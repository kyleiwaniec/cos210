/*<listing chapter="8" number="4">*/
package KW.CH08;

/** Implements the Shell sort algorithm.
 *  @author Koffman and Wolfgang
 **/
public class ShellSortMod implements SortAlgorithm {
// Insert solution to programming exercise 1, section 6, chapter 8 here
}
