// Insert solution to programming exercise 1, section 9, chapter 8 here
