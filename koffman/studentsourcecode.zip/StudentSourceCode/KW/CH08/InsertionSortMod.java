package KW.CH08;

/** Implements the insertion sort algorithm.
 *  @author Koffman and Wolfgang
 **/
public class InsertionSortMod implements SortAlgorithm {
// Insert solution to programming exercise 1, section 4, chapter 8 here
}
