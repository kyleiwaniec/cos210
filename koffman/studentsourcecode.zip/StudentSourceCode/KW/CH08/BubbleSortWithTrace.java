// Insert solution to programming exercise 1, section 3, chapter 8 here
