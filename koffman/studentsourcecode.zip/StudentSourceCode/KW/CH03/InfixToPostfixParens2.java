// Insert solution to programming exercise 1, section 4, chapter 3 here
// Insert solution to programming exercise 2, section 4, chapter 3 here
// Insert solution to programming exercise 2, section 4, chapter 3 here
// Insert solution to programming exercise 2, section 4, chapter 3 here
