package KW.CH03;

import java.util.Stack;

public class Exercise_3_1 {

    public static void main(String[] args) {

// Insert solution to programming exercise 1, section 1, chapter 3 here

// Insert solution to programming exercise 2, section 1, chapter 3 here

// Insert solution to programming exercise 3, section 1, chapter 3 here
    }
}
