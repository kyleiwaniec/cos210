// Insert solution to programming exercise 3, section 4, chapter 6 here
// Insert solution to programming exercise 2, section 4, chapter 6 here
