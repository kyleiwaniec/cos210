// Insert solution to programming exercise 1, section 2, chapter 10 here

