// Insert solution to programming exercise 2, section 4, chapter C here
