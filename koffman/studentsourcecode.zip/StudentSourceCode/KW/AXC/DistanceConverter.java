// Insert solution to programming exercise 1, section 5, chapter C here
