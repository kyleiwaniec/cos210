// Insert solution to programming exercise 2, section 7, chapter C here
