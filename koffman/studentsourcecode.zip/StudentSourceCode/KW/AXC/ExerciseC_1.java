/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KW.AXC;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Paul Wolfgang
 */
public class ExerciseC_1 {

    private static JFrame frame;

    public static void main(String[] args) {

        frame = new JFrame("Exercise C.1.1 and C.1.2");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
// Insert solution to programming exercise 1, section 1, chapter C here
        frame.add(submit);
        frame.pack();
        frame.setVisible(true);
    }

// Insert solution to programming exercise 2, section 1, chapter C here


}
