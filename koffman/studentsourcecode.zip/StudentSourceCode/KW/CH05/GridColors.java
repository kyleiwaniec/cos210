package KW.CH05;
// Insert solution to programming exercise 1, section 6, chapter 5 here
