//Exercise solution removed
// Insert solution to programming exercise 3, section 5, chapter 7 here
