// Insert solution to programming project 1, chapter -1 here
