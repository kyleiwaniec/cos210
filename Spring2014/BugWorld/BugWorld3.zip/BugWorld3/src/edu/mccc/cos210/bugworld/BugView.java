package edu.mccc.cos210.bugworld;

import java.awt.image.BufferedImage;

public abstract class BugView {
	public abstract BufferedImage drawBug();
}
